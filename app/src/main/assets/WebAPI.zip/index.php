<?php
$salt = '$up4rK';
if(isset($_GET['token'])){
	$timestamp = (isset($_GET['timestamp']) ? $_GET['timestamp'] : time());
	if(md5($timestamp.$salt) == $_GET['token'] || $_GET['token'] == 'debug'){
		$do = (isset($_GET['do']) ? $_GET['do'] : exit());
		require_once "connection.php";
		
		function getMax($region,$con){
			$query = mysqli_query($con,"SELECT time_parked, estimated_leave_time FROM parking WHERE parking_region = '".$region."';");
			$parkdata = [];
			while($data = mysqli_fetch_assoc($query)){
				$parkdata[count($parkdata)] = $data;
			}
			$max = 0;
			for($i = 0; $i < count($parkdata); $i++){
				$counter = 0;
				for($j = $i; $j < count($parkdata); $j++){
					if($parkdata[$j]['time_parked'] < $parkdata[$i]['estimated_leave_time']){
						$counter++;
					}
				}
				if($counter > $max){
					$max = $counter;
				}
			}
			return $max;
		}
		
		function getCurrent($region,$con){
			$time = time();
			$query = mysqli_query($con,"SELECT COUNT(park_id) as number FROM parking WHERE parking_region = '".$region."' 
			AND estimated_leave_time > '".$time."';");
			$data = mysqli_fetch_assoc($query);
			return $data['number'];
		}
		
		switch($do){
			case 'retrievedb': 
				$datatosend = []; $datatosend['zones'] = []; $datatosend['regions'] = []; $datatosend['lastupdate'] = [];
				$query = mysqli_query($con,"SELECT * FROM zones;");
				while($data = mysqli_fetch_assoc($query)){
					$datatosend['zones'][count($datatosend['zones'])] = $data;
				}
				$query = mysqli_query($con,"SELECT region_id,zone_id,name,AsText(location_poly) location_poly FROM regions;");
				while($data = mysqli_fetch_assoc($query)){
					$datatosend['regions'][count($datatosend['regions'])] = $data;
				}
				$query = mysqli_query($con,"SELECT time FROM lastupdate ORDER BY time DESC LIMIT 1;");
				while($data = mysqli_fetch_assoc($query)){
					$datatosend['lastupdate'] = $data;
				}
				$jsondata = json_encode($datatosend);
				mysqli_close($con);
			break;
			case 'addpark':
				$data = (@gzdecode($_POST['data']) ? json_decode(gzdecode($_POST['data'])) : json_decode($_POST['data']));
					if($data->uuid == "" || $data->time_parked == "" || $data->estimated_leave_time == "" || $data->parking_region == "" ||
					$data->parking_zone == ""){
						$jsondata = "error";
						if(!file_exists("log.txt")){ touch("log.txt"); }
						file_put_contents("log.txt",file_get_contents("log.txt")."\n".$_POST['data']);
					}else{
					$query = mysqli_query($con,"INSERT INTO parking VALUES ('null','".$data->uuid."','".$data->time_parked."',
					'".$data->estimated_leave_time."','".$data->parking_region."','".$data->parking_zone."','".$data->lat."','".$data->lon."');");
					$jsondata = ($query ? "done" : mysqli_error($con));
					}
			break;
			case 'latest':
				$query = mysqli_query($con,"SELECT time FROM lastupdate ORDER BY time DESC LIMIT 1;");
				while($data = mysqli_fetch_assoc($query)){
					$datatosend = $data;
				}
				$jsondata = json_encode($datatosend);
				mysqli_close($con);
			break;
			case 'getstats':
				$query = mysqli_query($con,"SELECT region_id FROM regions");
				$i = 0;
				while($data = mysqli_fetch_assoc($query)){
					$current = getCurrent($data['region_id'],$con); $max = getMax($data['region_id'],$con);
					$datatosend["regionstats"][$i]['region_id'] = $data['region_id'];
					$datatosend["regionstats"][$i]['current'] = $current;
					$datatosend["regionstats"][$i]['max'] = $max;
					$i++;
				}
				$jsondata = json_encode($datatosend);
			break;
			default: break;
		}
		echo (isset($jsondata) ? (isset($_GET['gzip']) ? gzencode($jsondata) : $jsondata) : "");
	}
}
?>