-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2016 at 09:42 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supark`
--

-- --------------------------------------------------------

--
-- Table structure for table `lastupdate`
--

CREATE TABLE `lastupdate` (
  `time` int(11) NOT NULL,
  `comment` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parking`
--

CREATE TABLE `parking` (
  `park_id` int(11) NOT NULL,
  `uuid` varchar(32) NOT NULL,
  `time_parked` int(11) NOT NULL,
  `estimated_leave_time` int(11) NOT NULL,
  `parking_region` int(11) NOT NULL,
  `parking_zone` int(11) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `region_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location_poly` polygon NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Triggers `regions`
--
DELIMITER $$
CREATE TRIGGER `regions_delete` AFTER DELETE ON `regions` FOR EACH ROW BEGIN
INSERT INTO lastupdate VALUES (UNIX_TIMESTAMP(),"Deletion from regions");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `regions_insert` AFTER INSERT ON `regions` FOR EACH ROW BEGIN
INSERT INTO lastupdate VALUES(UNIX_TIMESTAMP(),"New region");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `regions_update` AFTER UPDATE ON `regions` FOR EACH ROW BEGIN
INSERT INTO lastupdate VALUES (UNIX_TIMESTAMP(),"Update in regions");
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `zones`
--

CREATE TABLE `zones` (
  `zone_id` int(11) NOT NULL,
  `maxtime` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `priceperhour` double NOT NULL,
  `phone` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Triggers `zones`
--
DELIMITER $$
CREATE TRIGGER `zones_delete` AFTER DELETE ON `zones` FOR EACH ROW BEGIN
INSERT INTO zones VALUES(UNIX_TIMESTAMP(),"Deletion from zones");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `zones_insert` BEFORE INSERT ON `zones` FOR EACH ROW BEGIN
INSERT INTO zones VALUES(UNIX_TIMESTAMP(),"New zone");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `zones_update` AFTER UPDATE ON `zones` FOR EACH ROW BEGIN
INSERT INTO zones VALUES(UNIX_TIMESTAMP(),"Zones update");
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lastupdate`
--
ALTER TABLE `lastupdate`
  ADD PRIMARY KEY (`time`);

--
-- Indexes for table `parking`
--
ALTER TABLE `parking`
  ADD PRIMARY KEY (`park_id`),
  ADD KEY `uuid` (`uuid`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`region_id`);

--
-- Indexes for table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `parking`
--
ALTER TABLE `parking`
  MODIFY `park_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `region_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
