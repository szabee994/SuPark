<!doctype html>
<html>
<head>
<?php include "connection.php"; ?>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="1" style="text-align:center;">
  <tbody>
  <tr>
      <td>Park ID</td>
      <td>UUID</td>
      <td>Time parked</td>
      <td>Estimated leave time</td>
      <td>Region</td>
      <td>Zone</td>
      <td>Latitude</td>
      <td>Longitude</td>
    </tr>
  <?php
  function getColor($zoneid){
	  $return = "";
	  switch($zoneid){
		  case 1: $return = "#FF0000"; break;
		  case 2: $return = "#FFFF00"; break;
		  case 3: $return = "#00FF00"; break;
		  case 4: $return = "#0000FF"; break;
		  default: $return = "#FF0000"; break;
	  }
	  return $return;
  }
  
  $query = mysqli_query($con,"SELECT * FROM parking ORDER BY time_parked DESC;");
  while($data = mysqli_fetch_assoc($query)){
	  echo '
    <tr>
      <td>'.$data['park_id'].'</td>
      <td>'.$data['uuid'].'</td>
      <td>'.$data['time_parked'].'</td>
	  <td '.(time() > $data['estimated_leave_time'] ? 'style="background-color:#FF0000;"' : '').'>'.$data['estimated_leave_time'].'</td>
	  <td>'.$data['parking_region'].'</td>
  	  <td style="background-color:'.getColor($data['parking_zone']).';">'.$data['parking_zone'].'</td>
	  <td>'.$data['lat'].'</td>
	  <td>'.$data['lon'].'</td>
	  </tr>';
  }
  ?>
  </tbody>
</table>

</body>
</html>