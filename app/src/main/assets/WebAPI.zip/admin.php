<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<?php
include "connection.php";
if(isset($_POST['polygon'])){
	$sql = "INSERT INTO regions VALUES ('null','".$_POST['zoneid']."','".$_POST['name']."',PolyFromText('".$_POST['polygon']."'));";
	$query = mysqli_query($con,$sql);
	if(!$query){
		exit($sql."<br>".mysqli_error($con));
	}
}
if(isset($_GET['delete'])){
	$sql = "DELETE FROM regions WHERE region_id = '".$_GET['delete']."' LIMIT 1;";
	$query = mysqli_query($con,$sql);
}
?>
<script src="jquery-2.1.4.min.js" type="text/javascript" language="javascript"></script>
<script src="jquery-throttle-debounce.min.js" type="text/javascript" language="javascript"></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?signed_in=true&callback=getLocation&key=AIzaSyBm_EUzi0qRdNn1SKiAUDfY4d9BYaMdYAU"></script>
<script type="text/javascript">
color = '#FF0000';
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(initMap);
    } else {
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function colorSet(value){
	switch(value){
		case 1: color = "#FF0000"; break;
		case 2: color = "#FFFF00"; break;
		case 3: color = "#00FF00"; break;
		case 4: color = "#0000FF"; break;
	}
	if(markers.length > 2){
		createPoly();
	}
}

function showSqlPolys(){
	for(i = 0; i < sqlpolys.length; i++){
		sqlpolys[i].setMap(map);
	}
}

function hideSqlPolys(){
	for(i = 0; i < sqlpolys.length; i++){
		sqlpolys[i].setMap(null);
	}
}
</script>
</head>

<body>
<div id="map" style="width:1000px; height:800px; float:left;"></div>
<div id="content" style="width:400px; float:left; height:800px">
<input type="button" value="createPoly" onClick="createPoly()" /><input type="button" value="showSqlPolys()" onClick="showSqlPolys()" /><input type="button" value="hideSqlPolys()" onClick="hideSqlPolys()" /><br>
<form method="post" action="admin.php"><select id="colorchoose" name="zoneid" onChange="colorSet(this.value)"><option value="1">Red</option><option value="2">Yellow</option><option value="3">Green</option><option value="4">Blue</option></select>
<input type="text" name="polygon" id="polygon" /><br>
Name:<input type="text" name="name"/><br>
<input type="submit" />
</form>
</div>
    <script>
markers = [];
poly = null;

function initMap(position) {
  posi = position;
  var myLatLng = {lat: position.coords.latitude, lng: position.coords.longitude};
  $("#latitude").val(position.coords.latitude);
  $("#longitude").val(position.coords.longitude);
  
  poly = new google.maps.Polygon();

  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 13,
    center: myLatLng
  });
  
  map.addListener('click', function(event) {
    addMarker(event.latLng);
  });
  
  <?php 
$polys = [];
$zones = [];
$id = [];
$name = [];
$query = mysqli_query($con,"SELECT region_id,name,zone_id, AsText(location_poly) location_poly FROM regions");

while($data = mysqli_fetch_assoc($query)){
	$polys[] = $data['location_poly'];
	$zones[] = $data['zone_id'];
	$id[] = $data['region_id'];	
	$name[] = $data['name'];	
}
echo "
sqlpolys = [];
sqlcoords=[];
infowindow=[];\n";
for($i = 0; $i < count($polys); $i++){
	switch($zones[$i]){
		case "1": $color = "#FF0000"; break;
		case "2": $color = "#FFFF00"; break;
		case "3": $color = "#00FF00"; break;
		case "4": $color = "#0000FF"; break;
	}
	$polys[$i] = str_replace("POLYGON((","",$polys[$i]);
	$polys[$i] = str_replace("))","",$polys[$i]);
	$vertices = explode(",",$polys[$i]);
	echo "sqlcoords[".$i."] = [];\n";
	for($j = 0; $j < count($vertices); $j++){
		$latlng = explode(" ",$vertices[$j]);
		echo "sqlcoords[".$i."][".$j."] = {lat: ".$latlng['0'].", lng: ".$latlng['1']."};\n";
	}
	echo "
    infowindow[".$i."] = new google.maps.InfoWindow({
    content: '".$name[$i]." - Region ID: ".$id[$i]." - <br><a href=\"admin.php?delete=".$id[$i]."\">Delete</a>',
	position: sqlcoords[".$i."][0]
    });
    sqlpoly = new google.maps.Polygon({
    paths: sqlcoords[".$i."],
    strokeColor: \"".$color."\",
    strokeOpacity: 0.8,
    strokeWeight: 2,
    fillColor: \"".$color."\",
    fillOpacity: 0.35
    });
	sqlpoly.addListener('click',function(event) {
    infowindow[".$i."].open(map);
    });
    sqlpolys.push(sqlpoly);
";
}

?>
  
}

// Adds a marker to the map and push to the array.
function addMarker(location) {
  var marker = new google.maps.Marker({
    position: location,
    map: map,
	draggable: true,
	id: markers.length
  });
  marker.addListener('click', function(event){
	  this.setMap(null);
	  var currindex = this.id;
	  markers.splice(currindex,1);
	  createPoly();
  });
  marker.addListener('dragend', function(event){
	  createPoly();
  });
  markers.push(marker);
  if(markers.length > 2){
	  createPoly();
  }
}

function createPoly(){
	coords = [];
	poly.setMap(null);
	$("#polygon").val("POLYGON((");
	for(i = 0; i < markers.length; i++){
		coords[i] = {lat: markers[i].getPosition().lat(), lng: markers[i].getPosition().lng()};
		if(i == 0){
			$("#polygon").val($("#polygon").val()+markers[i].getPosition().lat()+" "+markers[i].getPosition().lng());
		}else{
			$("#polygon").val($("#polygon").val()+", "+markers[i].getPosition().lat()+" "+markers[i].getPosition().lng());
		}
		//markers[i].setMap(null);
	}
	$("#polygon").val($("#polygon").val()+", "+markers[0].getPosition().lat()+" "+markers[0].getPosition().lng());
	$("#polygon").val($("#polygon").val()+"))");
	polygon = new google.maps.Polygon({
    paths: coords,
    strokeColor: color,
    strokeOpacity: 0.8,
    strokeWeight: 2,
    fillColor: color,
    fillOpacity: 0.35
  });
//  markers = [];
  polygon.addListener('click', function(event){
	  this.setMap(null);
  });
  polygon.setMap(map);
  poly = polygon;
}
    </script>

</body>
</html>
